<p><b>Shortcontents</b></p>
<textarea id="shortcontents" name="shortcontents"><?=$groupRow['shortcontents'];?></textarea>
<p><b>Contents</b></p>
<textarea id="contents" name="contents"><?=$groupRow['contents'];?></textarea>
<script type="text/javascript">

	//CKEDITOR.basepath = "/ckeditor/";
	CKEDITOR.replace( 'shortcontents');
	CKEDITOR.replace( 'contents' );
	//var editor_data = CKEDITOR.instances.shortcontents.getData();
</script>
<?php
	// include ("../fckeditor/fckeditor.php");
	// $sBasePath="../fckeditor/";
	
	// $oFCKeditor = new FCKeditor('shortcontents');
	// $oFCKeditor->BasePath	= $sBasePath ;
	// $oFCKeditor->Value		= $groupRow['shortcontents'];
	// $oFCKeditor->Height		= "205";
	// $oFCKeditor->ToolbarSet	= "Rupens";	
	// $oFCKeditor->Create(); 
	
	// $oFCKeditor = new FCKeditor('contents');
	// $oFCKeditor->BasePath	= $sBasePath ;
	// $oFCKeditor->Value		= $groupRow['contents'];
	// $oFCKeditor->Height		= "300";
	// $oFCKeditor->ToolbarSet	= "Rupens";	
	// $oFCKeditor->Create(); 	
?>